<?php

namespace fast;

use fast\Http;

/**
 * Http 请求类
 */
class Telegram
{
    private $botToken;
    private $prefixUrl;
    public $replymarkup;
    public function __construct($botToken){
        $this->botToken = $botToken;
        $this->prefixUrl = 'https://api.telegram.org/bot'.$this->botToken.'/';
        //第一行
        $this->replymarkup['inline_keyboard'][0] = [['text'=>'查看余额','callback_data'=>'/yue'],['text'=>'最近投注','callback_data'=>'/order']];
        $this->replymarkup['inline_keyboard'][1] = [['text'=>'资金明细','callback_data'=>'/mx'],['text'=>'充值提现','url'=>config('site.kfurl')]];
    }
    
    public function deleteWebhook(){
        //{"ok":true,"result":true,"description":"Webhook was deleted"}
        $url = $this->prefixUrl.'deleteWebhook';
        $result = Http::get($url);
        $result = json_decode($result, true);
        return ["result"=>$result['ok'], 'description'=>$result['description']];
    }
    
    public function setWebhook($weburl){
        //{"ok":true,"result":true,"description":"Webhook was set"}
        $url = $this->prefixUrl.'setWebhook';
        $options[CURLOPT_HTTPHEADER] = ["Content-type: application/json;charset='utf-8'"];
        $result = Http::post($url, json_encode(['url'=>$weburl]), $options);
        $result = json_decode($result, true);
        return ["result"=>$result['ok'], 'description'=>$result['description']];
    }
    
    public function sendMessage($params){
        $url = $this->prefixUrl.'sendmessage';
        $options[CURLOPT_HTTPHEADER] = ["Content-type: application/json;charset='utf-8'"];
        $result = Http::post($url, json_encode($params), $options);
        $result = json_decode($result, true);
        return $result;
    }
    
    public function answerCallbackQuery($params){
        $url = $this->prefixUrl.'answerCallbackQuery';
        $options[CURLOPT_HTTPHEADER] = ["Content-type: application/json;charset='utf-8'"];
        $result = Http::post($url, json_encode($params), $options);
        $result = json_decode($result, true);
        return $result;
    }
    
    public function sendDice($params){
        $url = $this->prefixUrl.'sendDice';
        $options[CURLOPT_HTTPHEADER] = ["Content-type: application/json;charset='utf-8'"];
        $result = Http::post($url, json_encode($params), $options);
        $result = json_decode($result, true);
        return $result;
    }
}
